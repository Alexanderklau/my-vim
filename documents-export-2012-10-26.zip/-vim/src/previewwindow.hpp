#ifndef _PREVIEWWINDOW_HPP
#define _PREVIEWWINDOW_HPP
char* preview_window(vector<const string> &v,const string& base,int x,int y,int width,int height);
#endif
//test

